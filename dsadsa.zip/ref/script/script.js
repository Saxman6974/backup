$(document).ready(function()
{
    $(".contentsImageList li").eq(1).hide();
    $(".contentsImageList li").eq(2).hide();
    $(".eastSlotList li").eq(1).hide();
    $(".eastSlotList li").eq(2).hide();
    $(".contetnsList li").click(function(){
        var list = $(this).index();
        $(".contetnsList > li").removeClass("on");
        $(".contetnsList > li").eq(list).addClass("on");
        $(".contentsImageList li").hide();
        $(".eastSlotList > li").hide();
        $(".contentsImageList li").eq(list).show();
        $(".eastSlotList > li").eq(list).show();
    });
    $(".headerList_1 li").mouseenter(function(){
        $(this).find(".headerSubList_1").stop().slideDown();
    });
    $(".headerList_1 li").mouseleave(function(){
        $(this).find(".headerSubList_1").stop().slideUp();
    });

    $(".extraList li").click(function(){
        $("#contents").animate({top: "400px"}, 400);
    });
    $("#s2").mouseleave(function(){
        $("#contents").animate({top: "19.75%"}, 400);
    });
});